package org.asu.group8.model;

public class ModifyAccountResponse {

    private Boolean modified;

    public Boolean getModified() {
        return modified;
    }

    public void setModified(Boolean modified) {
        this.modified = modified;
    }

}
