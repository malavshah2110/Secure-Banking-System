package org.asu.group8.model;

public class ModifyUserResponse {

    private Boolean requested;
    private Boolean modified;

    public Boolean getRequested() {
        return requested;
    }

    public void setRequested(Boolean requested) {
        this.requested = requested;
    }

    public Boolean getModified() {
        return modified;
    }

    public void setModified(Boolean modified) {
        this.modified = modified;
    }

}
