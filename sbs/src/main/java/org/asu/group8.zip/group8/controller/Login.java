package org.asu.group8.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
public class Login {

    /*
    @RequestMapping("/login")
    public String loginCsrf(Map<String, Object> model) {
        return "login";
    }

    @RequestMapping("/login_tech")
    public String loginTechCsrf(Map<String, Object> model) {
        return "login_tech";
    }
    */

}
