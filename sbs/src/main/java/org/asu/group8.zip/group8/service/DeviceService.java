package org.asu.group8.service;

public interface DeviceService {

    String createDevice(String username);

}
