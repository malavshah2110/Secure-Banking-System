package org.asu.group8.model;

public class ResolveModifyUsersResponse {

    public Boolean resolved;

    public Boolean getResolved() {
        return resolved;
    }

    public void setResolved(Boolean resolved) {
        this.resolved = resolved;
    }
}
